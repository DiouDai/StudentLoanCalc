import java.util.ArrayList;

public class StackedBarChart extends StudentCalc { 
   @Override     
   public void start(Stage primaryStage) throws Exception {     
   }    
   
 //Defining the x axis               
   CategoryAxis xAxis = new CategoryAxis(); 
   ArrayList Years = New ArrayList<>;
   for (int i = PaymentStartDate, i< PaymentStartDate+NbrOfYears+1,i++) {
	   Years.add(i);
   }
   xAxis.setCategories(FXCollections.<int>observableArrayList(Years));
   xAxis.setLabel("Year");  

   //Defining the y axis 
   NumberAxis yAxis = new NumberAxis(); 
  
   yAxis.setLabel("Payment");
   StackedBarChart<String, Number> stackedBarChart = 
		   new StackedBarChart<>(xAxis, yAxis);         
		   stackedBarChart.setTitle("Payment Per Year"); 
		 //Prepare XYChart.Series objects by setting data 
		   XYChart.Series<String, Number> series1 = new XYChart.Series<>(); 
		   series1.setName("Princlple"); 
		
		   
		   XYChart.Series<String, Number> series2 = new XYChart.Series<>();  

		   series2.setName("Interest"); 
		   
		   stackedBarChart.getData().addAll(series1, series2); 
		   Group root = new Group(stackedBarChart); 
		   Scene scene = new Scene(group ,600, 300);
		   primaryStage.setTitle("Sample Application"); 
		   primaryStage.setScene(scene);
		   primaryStage.show();
		   public static void main(String args[]){   
			   launch(args);      
			} 

}
